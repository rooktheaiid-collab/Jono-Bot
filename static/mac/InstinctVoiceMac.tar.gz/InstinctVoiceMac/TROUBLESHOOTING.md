# Instinct Voice (macOS) v3: troubleshooting

Install: `bash install.sh` (add `--login` to start at login, `--uninstall` to remove).
Needs macOS 12 or newer and Xcode Command Line Tools (`xcode-select --install`).

## Pakai (v3)
- Ikon gelombang di menu bar. Klik kiri atau Option+Spasi: sepasang mata kartun melayang di pojok kanan atas dan sesi suara langsung mulai. Pupil mengikuti kursor, mata berkedip sendiri. Pola mata mengikuti keadaan: kotak datar (siap), serius (menyambung), bulat (mendengarkan), bingung (mikir), ^^ + loncat halus (bicara), sedih (error), ngantuk (sesi selesai sendiri, lalu hilang).
- Klik mata (atau Option+Spasi lagi) = hentikan sesi dan tutup. Klik kanan atau tahan mata >0,5 detik = buka panel penuh (passcode, setelan, riwayat, tema). Klik kanan ikon menu bar = menu.
- Pertama kali belum ada passcode: panel penuh otomatis terbuka, isi passcode sekali (tersimpan lokal), tekan Mulai ngobrol. Setelah itu cukup mata.
- Tutup panel (X, Cmd+W, hotkey): sesi dihentikan, mic dilepas. Setelah 2 menit tanpa tampilan, halaman dikosongkan supaya memori balik.

## Masalah umum
1. Dialog install Command Line Tools muncul / "swiftc not found": selesaikan install-nya, jalankan lagi `bash install.sh`.
2. Mic tidak jalan / tidak ada prompt: buka System Settings > Privacy & Security > Microphone, nyalakan "Instinct Voice". Kalau tidak ada di daftar atau sudah ditolak: `tccutil reset Microphone id.reza.voicemenu`, buka app lagi, klik Mulai ngobrol. Setiap kali app di-build ulang, macOS bisa minta izin lagi (tanda tangan ad-hoc berubah).
3. Hotkey Option+Spasi tidak merespons: kemungkinan dipakai app lain (Alfred, Raycast, ChatGPT, dll). Menu klik kanan akan menampilkan "Hotkey gagal" kalau pendaftaran ditolak. Ganti hotkey lalu buka ulang app:
   `defaults write id.reza.voicemenu hotkeyKey -int 49` (49 = Spasi; mis. 2 = D, 40 = K)
   `defaults write id.reza.voicemenu hotkeyMods -int 4096` (Option 2048, Control 4096, Shift 512, Command 256; jumlahkan untuk kombinasi, mis. Control+Option = 6144)
   Kembalikan ke bawaan: `defaults delete id.reza.voicemenu hotkeyKey; defaults delete id.reza.voicemenu hotkeyMods`.
4. Panel menampilkan "Tidak bisa konek ke server": cek internet, tutup lalu buka lagi panelnya, atau menu > Muat ulang.
5. Passcode salah atau mau ganti: menu klik kanan > "Reset passcode dan data", lalu isi ulang.
6. Macet / suara tidak keluar: menu > Muat ulang. Pastikan output suara Mac tidak mute.
7. "app dari developer tidak dikenal": install.sh sudah menghapus karantina dan menandatangani ad-hoc. Kalau tetap diblok: klik kanan InstinctVoice.app di ~/Applications > Open.
8. Mau hapus: `bash install.sh --uninstall`.
9. Mata muncul tapi tidak mulai mendengarkan: kemungkinan passcode belum tersimpan (panel akan terbuka) atau izin mikrofon belum diberikan (lihat nomor 2). Coba Muat ulang dari menu, lalu panggil lagi.
10. Pupil tidak mengikuti kursor: pastikan app tidak di-pause; coba panggil ulang dengan hotkey.
