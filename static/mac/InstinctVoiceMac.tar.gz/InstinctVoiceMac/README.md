# Instinct Voice for macOS v3

Menu-bar app (Swift + WKWebView, system WebView, no Electron) that loads https://101-32-114-234.sslip.io/.
v3: summon = a pair of cartoon eyes drawn in code (Core Graphics, 60 fps timer only while shown): pupils follow the cursor with spring physics, natural blinking, 11 expression variants morphing in ~300 ms, expression follows the app state (page reports body data-state/data-err via WKScriptMessageHandler). Click = stop and dismiss; right-click or long-press = full panel.
Files: main.swift (whole app), Info.plist, install.sh (self-contained: embeds both, compiles with swiftc, ad-hoc codesigns, installs to ~/Applications), TROUBLESHOOTING.md.
Hotkey: Carbon RegisterEventHotKey, default Option+Space (configurable via defaults).
Mic: NSMicrophoneUsageDescription + AVCaptureDevice.requestAccess + WKUIDelegate media-capture grant for the app's own host only.
No secrets here; the passcode is typed once in the panel and kept in the WebView's local storage.
